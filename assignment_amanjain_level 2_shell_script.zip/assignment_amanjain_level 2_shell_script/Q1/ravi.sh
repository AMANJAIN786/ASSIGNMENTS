#**************************************************
#  ravi.sh
#  Created by AMAN JAIN (amanjainmahaveer@gmail.com) on 08/06/19.
# Description: SHELL SCRIPT ASSIGNMENT 
# ORGANISATION:EITRA TRAINING RESEARCH CENTER 
#**************************************************
#!/bin/bash
f1()
{
RANDOM=$$
for i in `seq 1000`
do
   echo $RANDOM
done
}
f2()
{
for i in `seq 1000`
do
od -An -N1 -i /dev/urandom
done
}
f3()
{
for i in `seq 1000`
do
od -An -N1 -i /dev/random
done
}

start1=$(date +%S%4N)
f1 > 1.txt
endtime1=$(date +%S%4N)
F1=$(($endtime1-$start1))
echo "f1 : $F1"
start2=$(date +%S%4N)
f2 > 2.txt
endtime2=$(date +%S%4N)
F2=$(($endtime2-$start2))
echo "f2 : $F2"
start3=$(date +%S%4N)
f3 > 3.txt
endtime3=$(date +%S%4N)
F3=$(($endtime3-$start3))
echo "f3 : $F3"
if [ $F1 -gt $F2 ] && [ $F1 -gt $F3 ]
then  
echo "f1 is biggest number"
elif [ $F2 -gt $F1 ] && [ $F2 -gt $F3 ]
then
echo "f2 is biggest number"
else
echo "f3 is biggest number"
fi

if [ $F1 -lt $F2 ] && [ $F1 -lt $F3 ]
then  
echo "f1 is lowest number"
elif [ $F2 -lt $F1 ] && [ $F2 -lt $F3 ]
then
echo "f2 is lowest number"
else
echo "f3 is lowest number"
fi

