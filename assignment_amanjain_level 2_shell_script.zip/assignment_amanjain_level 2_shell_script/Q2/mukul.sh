#**************************************************
#  mukul.sh
#  Created by AMAN JAIN (amanjainmahaveer@gmail.com) on 08/06/19.
# Description: SHELL SCRIPT ASSIGNMENT 
# ORGANISATION:EITRA TRAINING RESEARCH CENTER 
#**************************************************
#!/bin/bash
f1 ()
{
sed -i 's/asic_jan2018/EITRA_ASIC_JULY_2019/g' asic_jan2018_*.sv
}
f1
