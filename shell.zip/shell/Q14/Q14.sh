#**************************************************
#  Q14.sh
#  Created by AMAN JAIN (amanjainmahaveer@gmail.com) on 08/01/19.
# Description: SHELL SCRIPT ASSIGNMENT 
# ORGANISATION:EITRA TRAINING RESEARCH CENTER 
#**************************************************
#!/bin/bash
if [ $# -eq 0 ] 
then
    echo "$0:Error command arguments missing!"
    echo "Usage: $0 start_line   uptoline   filename"
    echo "Where start_line is line number from which you would like to print file"
    echo "uptoline is line number upto which would like to print"
fi
     if [ $# -eq 3 ]; then
	if [ -e $3 ]; then
    	    tail $3 | head -n$2
         else
    	    echo "$0: Error opening file $3" 
	    exit
	fi   
    else
        echo "Missing arguments!"	
    fi
