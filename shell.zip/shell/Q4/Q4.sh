#!/bin/bash
i=5
while test $i != 0
do
printf "$i,"
i=`expr $i - 1`
done

