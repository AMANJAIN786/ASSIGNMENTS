#**************************************************
#  Q6.sh
#  Created by AMAN JAIN (amanjainmahaveer@gmail.com) on 08/01/19.
# Description: SHELL SCRIPT ASSIGNMENT 
# ORGANISATION:EITRA TRAINING RESEARCH CENTER 
#**************************************************
#!/bin/bash
if test $# = 3
then
	case $2 in
	 +) let z=$1+$3;;
	 -) let z=$1-$3;;
	 /) let z=$1/$3;;
	 x|X) let z=$1*$3;;
	 *) echo Warning - $2 invalied operator, only +,-,x,/ operator allowed
	    exit;;
	esac
	echo Answer is $z
fi
