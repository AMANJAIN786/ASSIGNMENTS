#**************************************************
#  Q20.sh
#  Created by AMAN JAIN (amanjainmahaveer@gmail.com) on 08/02/19.
# Description: SHELL SCRIPT ASSIGNMENT 
# ORGANISATION:EITRA TRAINING RESEARCH CENTER 
#**************************************************
#!/bin/bash
read -p "What is your first name? " firstname
firstname=${firstname,,}
echo "Hello, ${firstname}."
y="AMAN JAIN"
echo "${y^^}"
y="aman jain"
echo "${y,,}"


