#**************************************************
#  Q9.sh
#  Created by AMAN JAIN (amanjainmahaveer@gmail.com) on 08/01/19.
# Description: SHELL SCRIPT ASSIGNMENT 
# ORGANISATION:EITRA TRAINING RESEARCH CENTER 
#**************************************************
#!/bin/bash
seconds=0

echo -n "Enter number of seconds : "
read seconds

hours=$((seconds / 3600))
seconds=$((seconds % 3600))
minutes=$((seconds / 60))
seconds=$((seconds % 60))

echo "$hours:$minutes:$seconds"
