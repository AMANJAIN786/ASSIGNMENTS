#**************************************************
#  Q18.sh
#  Created by AMAN JAIN (amanjainmahaveer@gmail.com) on 08/01/19.
# Description: SHELL SCRIPT ASSIGNMENT 
# ORGANISATION:EITRA TRAINING RESEARCH CENTER 
#**************************************************
#!/bin/bash
while :
do
    ti=`date +"%r"`      
    echo -e -n "\033[7s"    
    tput cup 0 69
        echo -n $ti
    echo -e -n "\033[8u"
  sleep 1
done
