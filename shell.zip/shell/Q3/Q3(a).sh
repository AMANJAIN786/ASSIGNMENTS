#!/bin/bash
myname=amanjain
echo hello $myname
