#!/bin/bash
echo hello $@


