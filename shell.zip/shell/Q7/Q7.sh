#**************************************************
#  Q7.sh
#  Created by AMAN JAIN (amanjainmahaveer@gmail.com) on 08/01/19.
# Description: SHELL SCRIPT ASSIGNMENT 
# ORGANISATION:EITRA TRAINING RESEARCH CENTER 
#**************************************************
#!/bin/bash
echo " $LOGNAME "
echo "Current date is `date`"
echo " user is `who i am` "
echo "current directory `pwd`"
