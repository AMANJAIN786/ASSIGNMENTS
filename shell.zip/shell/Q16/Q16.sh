#**************************************************
#  Q16.sh
#  Created by AMAN JAIN (amanjainmahaveer@gmail.com) on 08/01/19.
# Description: SHELL SCRIPT ASSIGNMENT 
# ORGANISATION:EITRA TRAINING RESEARCH CENTER 
#**************************************************
#!/bin/bash
let=`date | cut -c12-13`
dat=`date +"%A %d in %B of %Y (%r)"`

if [ $let -lt 12 ]
then
    mess="Good Morning $LOGNAME, Have nice day!"
fi

if [ $let -gt 12 -a $let -le 16 ]
then
    mess="Good Afternoon $LOGNAME"
fi

if [ $let -gt 16 -a $let -le 18 ]
then
    mess="Good Evening $LOGNAME"
fi
    echo -e "$mess\nThis is $dat"

