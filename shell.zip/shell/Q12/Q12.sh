#**************************************************
#  Q12.sh
#  Created by AMAN JAIN (amanjainmahaveer@gmail.com) on 08/01/19.
# Description: SHELL SCRIPT ASSIGNMENT 
# ORGANISATION:EITRA TRAINING RESEARCH CENTER 
#**************************************************
#!/bin/bash
filename=$1
result=`locate -c $filename`
if [ -n $result ]
then
echo " this $result exists "
else
echo "this $filename doesn't exist"
fi
